#include <iostream>
#include <string>
using namespace std;

class PlayerMoney
{
    private:
        int startingAmount=10000;
    public:
        PlayerMoney();
        void moneyTracker();
};