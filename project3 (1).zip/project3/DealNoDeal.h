#include <iostream>
#include <string>
using namespace std;

class DealNoDeal
{
    private:
        int briefcases[][];
        int choice1;
        int choice2;
    public:
        DealNoDeal();
        DealNoDeal(int, int);
        
        int getBriefCaseValue();
        int alternativeChoice();
        void userBriefcaseChoice(int);
        void userDealChoice(int);
        
};