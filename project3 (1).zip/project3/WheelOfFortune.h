#include <iostream>
#include <string>
using namespace std;

class WheelOfFortune
{
    public:
        WheelOfFortune();
        WheelOfFortune(string);
        
        int wheelMovement[];
};