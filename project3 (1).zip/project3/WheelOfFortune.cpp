#include <iostream>
#include <string>
#include "WheelOfFortune"
using namespace std;

WheelOfFortune::WheelOfFortune()
{
    //file that I make that has wheel elements in an array
}
WheelOfFortune::WheelOfFortune(string spin)
{
    //when user types spin then it sets off function for the wheel movement
    //Use a randomizer to make the spin random each time
    //It then returns the number that the the wheel arrow landed on
}
int WheelOfFortune::WheelMovement()
{
    //sorts array in a way that makes it like a spin- first element becomes second element
    //second element moves to third element and last element goes to first element etc...
    //prints out the array each time so user can see how it "spins"
    //randomizer controls how long it should spin
}
