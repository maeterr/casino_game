#include <iostream>
#include <string>
#include "DealNoDeal.h"
using namespace std;

DealNoDeal::DealNoDeal()
{
    briefcases[3][3];
    
}
DealNoDeal::DealNoDeal(int, int)
{
    //prints what the value in the briefcase is no matter what decision and then
    //adds money to bank 
}
int DealNoDeal::getBriefCaseValue()
{
    //reads from an array file and takes the users choice for what briefcase they
    //want and gives the briefcase value for that choice.
}
int DealNoDeal::alternativeChoice()
{
    //uses a randomizer to get another dollar amount as an offer
}
void DealNoDeal::userBriefcaseChoice(int i)
{
    DealNoDeal::choice1=i;
}
void DealNoDeal::userDealChoice(int j)
{
    DealNoDeal::choice2=j
}