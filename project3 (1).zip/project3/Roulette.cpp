#include <iostream>
#include <string>
#include "Roulette.h"
using namespace std;

Roulette::Roulette()
{
    //player can only pick one of the options to bet on, and they place their 
    //bets and money grows depending on which choice and if you win
}
int Roulette::singleNumber(int numberChoice)
{
    //convert number choice to a string using stoi
    Roulette::playerChoice=numberChoice;
}
int Roulette::highLow(string highLowChoice)
{
    Roulette::playerChoice=highLowChoice;
}
int Roulette::redBlack(string redBlackChoice)
{
    Roulette::playerChoice=redBlackChoice;
}
int Roulette::oddEven(string oddEvenChoice)
{
    Roulette::playerChoice=oddEvenChoice;
}
