#include <iostream>
#include <string>
using namespace std;

PlayerMoney::PlayerMoney()
{
    startingAmount=10000;
    
}
void PlayerMoney::moneyTracker()
{
    //adds or subtracts money to a vector anytime you win or lose in one of the
    //games. prints amount of money you currently have and a record of your wins 
    //and loses.
}