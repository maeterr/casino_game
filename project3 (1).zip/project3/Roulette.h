#include <iostream>
#include <string>
using namespace std;

class Roulette
{
    private:
        string playerChoice;
    public:
        Roulette();
        int singleNumber(int);
        int highLow(string);
        int redBlack(string);
        int oddEven(string);
};